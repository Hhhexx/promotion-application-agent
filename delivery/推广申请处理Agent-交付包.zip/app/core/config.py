"""运行配置。

演示态不引入配置中心；所有可调项集中在此，便于审计。
"""

from __future__ import annotations

import os
from pathlib import Path

#: 仓库根目录（本文件位于 app/core/config.py）。
ROOT_DIR = Path(__file__).resolve().parents[2]

#: 仓储内自带的账号表源文件（只读，永不修改）。
DEFAULT_SOURCE_TABLE = ROOT_DIR / "data" / "你是我的仰望-推广账号表.xlsx"

#: 测试副本输出目录。
TEST_COPY_DIR = ROOT_DIR / "data" / "test-copies"

#: 裁决日志（append-only JSONL）。
DECISION_LOG = ROOT_DIR / "data" / "decisions" / "decisions.jsonl"

#: 前端静态资源目录。
WEB_DIR = ROOT_DIR / "web"

#: 金额量化精度（保 2 位，禁止 float 参与运算）。
MONEY_EXP = "0.01"

#: LLM 旁路开关：无密钥时自动降级为 no-op，主流程不受影响（架构 §5.4）。
LLM_API_KEY_ENV = "LLM_API_KEY"
LLM_BASE_URL_ENV = "LLM_BASE_URL"
LLM_MODEL_ENV = "LLM_MODEL"


def llm_enabled() -> bool:
    """环境变量存在密钥时才认为 LLM 旁路可用。"""
    return bool(os.environ.get(LLM_API_KEY_ENV))


def ensure_dirs() -> None:
    """确保运行期需要的目录存在。"""
    TEST_COPY_DIR.mkdir(parents=True, exist_ok=True)
    DECISION_LOG.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_SOURCE_TABLE.parent.mkdir(parents=True, exist_ok=True)
