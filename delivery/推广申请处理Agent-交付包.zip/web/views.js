/* 渲染层：把接口数据渲染成界面。不含请求逻辑，纯函数式（输入 state，输出 DOM）。 */

const COL_LABEL = {
  type: '类型', douyin_nickname: '抖音昵称', douyin_id: '抖音号', quote_price: '报价',
  doujia_amount: '抖加', doujia_payer: '抖加支付人', is_paid: '是否打款', payer: '打款人',
  pay_date: '打款日期', publish_date: '发布日期', accepted: '是否接单',
  review_result: '审核结果', remark: '备注',
};

const STEPS = [
  { key: 'table', label: '登记测试副本' },
  { key: 'input', label: '粘贴申请文本' },
  { key: 'parse', label: '解析与校验' },
  { key: 'judge', label: '人工裁决' },
  { key: 'commit', label: '写入副本' },
  { key: 'report', label: '汇总与汇报' },
];

function renderStepper(flags) {
  document.getElementById('stepper').innerHTML = STEPS.map((step, idx) => {
    const status = flags[step.key] || 'idle';
    const cls = status === 'done' ? 'step done' : status === 'active' ? 'step active' : 'step';
    return `<span class="${cls}">${UI.esc(String(idx + 1).padStart(2, '0'))}　${UI.esc(step.label)}</span>`;
  }).join('');
  UI.refreshIcons();
}

function countBySeverity(result) {
  const out = { P0: 0, P1: 0, P2: 0, open: 0, total: 0 };
  if (!result) return out;
  result.anomalies.forEach((a) => {
    out[a.severity] += 1;
    out.total += 1;
    if (!a.resolved && a.blocking) out.open += 1;
  });
  return out;
}

function renderCounts(result, filter) {
  const host = document.getElementById('counts');
  if (!result) {
    host.innerHTML = UI.emptyState('尚未解析。载入或粘贴申请文本后开始校验。', 'scan-text');
    return;
  }
  const c = countBySeverity(result);
  const cells = [
    { tone: 'block', sev: 'P0', label: '阻断', value: c.P0, note: '禁止写入' },
    { tone: 'warn', sev: 'P1', label: '警告', value: c.P1, note: '可写但标注待确认' },
    { tone: 'ok', sev: 'P2', label: '提示', value: c.P2, note: '观察性提示' },
  ];
  host.innerHTML = cells.map((cell) => `
    <button class="counter" type="button" data-tone="${cell.tone}" data-sev="${cell.sev}"
      data-active="${filter === cell.sev}">
      ${UI.icon(cell.sev === 'P2' ? 'info' : UI.SEV_TONE[cell.sev] === 'block' ? 'octagon-alert' : 'triangle-alert', 16)}
      <span>${UI.esc(cell.label)}</span>
      <span class="num">${cell.value}</span>
      <span class="pill">${UI.esc(cell.note)}</span>
    </button>`).join('');
  UI.refreshIcons();
}

function renderMeta(result) {
  const host = document.getElementById('request-meta');
  if (!result) {
    host.innerHTML = '';
    return;
  }
  const c = result.cross_check;
  const bizLabel = result.biz_type === 'doujia' ? '抖加申请' : '垫付申请';
  host.innerHTML = `
    <div><strong>${UI.esc(bizLabel)}</strong>　批次 ${UI.esc(result.batch_id)}</div>
    <div>申请日 ${UI.esc(result.request_date)}　明细 ${c.line_items_len} 行　声明 `+
    `${UI.esc(c.declared_count === null ? '—' : c.declared_count)} 笔 / 折算 ${UI.esc(c.split_count_sum)} 笔</div>
    <div>明细求和 ${UI.esc(UI.money(c.line_items_sum))}　声明总额 ${UI.esc(UI.money(c.declared_total_amount))}</div>`;
  UI.refreshIcons();
}

function renderQueue(state) {
  const host = document.getElementById('queue');
  const chips = document.getElementById('queue-chips');
  const result = state.result;
  if (!result) {
    chips.innerHTML = '';
    host.innerHTML = UI.emptyState('解析后在此列出待裁决项，阻断项排在最前。', 'list-filter');
    return;
  }
  const groups = [
    { key: 'P0', label: '口径不自洽 / 重复 / 日期', n: 0 },
    { key: 'P1', label: '字段缺失 / 待确认', n: 0 },
    { key: 'P2', label: '提示项', n: 0 },
  ];
  const rank = { P0: 0, P1: 1, P2: 2 };
  const cached = result.anomalies.filter((a) => a.code.indexOf('TABLE_') === 0 || a.rule_id.indexOf('table.') === 0);
  const scoped = result.anomalies.filter((a) => !(a.code.indexOf('TABLE_') === 0 || a.rule_id.indexOf('table.') === 0));
  const render = scoped.concat(cached);
  render.forEach((a) => { groups.find((g) => g.key === a.severity).n += 1; });

  chips.innerHTML = '<button class="chip" data-filter="all" aria-pressed="' + (state.filter === 'all') + '">全部 ' +
    result.anomalies.length + '</button>' +
    groups.map((g) => `<button class="chip" data-filter="${g.key}" aria-pressed="${state.filter === g.key}">${UI.esc(g.label)} ${g.n}</button>`).join('');

  const list = render
    .filter((a) => !state.filter || state.filter === 'all' || a.severity === state.filter)
    .sort((a, b) => (rank[a.severity] - rank[b.severity]) ||
      ((b.impact_amount || 0) - (a.impact_amount || 0)));

  if (!list.length) {
    host.innerHTML = UI.emptyState('没有符合筛选条件的项目。', 'inbox');
    return;
  }
  host.innerHTML = list.map((a) => `
    <li class="queue-item${a.resolved ? ' is-resolved' : ''}" data-sev="${a.severity}"
        data-id="${UI.esc(a.anomaly_id)}" aria-current="${state.selectedId === a.anomaly_id}">
      <span class="sev"></span>
      <span>
        <span class="qi-title">${UI.esc(a.message)}</span>
        <span class="qi-meta">
          <span class="pill">${UI.esc(a.exc_id || a.code)}</span>
          ${a.account_ref ? `<span>${UI.icon('user-round', 16)} ${UI.esc(a.account_ref)}</span>` : ''}
          ${a.line_no ? `<span>第 ${UI.esc(a.line_no)} 行</span>` : ''}
          ${a.resolved ? `<span class="pill" data-tone="ok">${UI.icon('circle-check', 16)}已裁决</span>` : ''}
        </span>
      </span>
      <span>${UI.sevPill(a.severity)}</span>
    </li>`).join('');
  UI.refreshIcons();
}

function sheetRowTable(row, conflictField) {
  if (!row) return '';
  const keys = Object.keys(COL_LABEL);
  const head = ['字段', '单元格值'].map((h) => `<th>${UI.esc(h)}</th>`).join('');
  const body = keys.map((key) => {
    const raw = row.values[key];
    const empty = raw === null || raw === undefined || String(raw).trim() === '';
    const cls = key === conflictField ? 'cell-conflict' : empty ? 'cell-empty' : '';
    return `<tr><td>${UI.esc(COL_LABEL[key])}</td><td class="${cls}">${UI.plain(raw)}</td></tr>`;
  }).join('');
  return `<table class="sheet-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function renderEvidence(state) {
  const host = document.getElementById('evidence');
  const result = state.result;
  const anomaly = result && state.selectedId
    ? result.anomalies.find((a) => a.anomaly_id === state.selectedId)
    : null;
  if (!anomaly) {
    host.innerHTML = UI.emptyState('在左侧队列选择一项，查看问题、证据与影响。', 'quote');
    return;
  }
  const row = state.tableDetail && anomaly.sheet_row_ref
    ? state.tableDetail.rows.find((r) => r.row_ref === anomaly.sheet_row_ref)
    : null;

  let leftBody;
  if (anomaly.source_span) {
    leftBody = UI.highlightSource(state.rawText || '', anomaly.source_span, anomaly.text_value);
  } else if (anomaly.text_value) {
    leftBody = UI.highlightToken(state.rawText || '', anomaly.text_value);
  } else {
    leftBody = '<span class="ev-text">（本项为表级体检，无对应文本片段）</span>';
  }
  const leftLabel = anomaly.source_span ? '来源文本片段' : '文本侧取值';

  let rightBody;
  if (row) {
    rightBody = sheetRowTable(row, anomaly.target_field);
  } else if (anomaly.sheet_value) {
    rightBody = `<div class="ev-text">${UI.esc(anomaly.sheet_value)}</div>`;
  } else {
    rightBody = '<div class="ev-text">（台账侧无对应取值）</div>';
  }
  const rightLabel = row ? `账号表 · 第 ${row.row_ref} 行` : '台账 / 明细侧取值';

  const impact = [];
  if (anomaly.impact_amount !== null && anomaly.impact_amount !== undefined) {
    impact.push(`影响金额 ${UI.money(anomaly.impact_amount)}`);
  }
  if (anomaly.action_required) impact.push(UI.esc(anomaly.action_required));
  if (anomaly.suggestion) impact.push(`建议：${UI.esc(anomaly.suggestion)}`);
  if (anomaly.evidence_note) impact.push(UI.esc(anomaly.evidence_note));

  host.innerHTML = `
    <p class="ev-claim">${UI.esc(anomaly.message)}</p>
    <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;">
      ${UI.sevPill(anomaly.severity)}
      <span class="pill">${UI.icon('gavel', 16)}规则 ${UI.esc(anomaly.rule_id)}</span>
      <span class="pill">${UI.esc(anomaly.exc_id || anomaly.code)}</span>
      <span class="pill" data-tone="${anomaly.blocking ? 'block' : 'info'}">${anomaly.blocking ? '阻断写表' : '不阻断'}</span>
    </div>
    <div class="ev-section">
      <h4>② 证据对照</h4>
      <div class="ev-compare">
        <div class="ev-pane"><h5>${UI.icon('quote', 16)} ${UI.esc(leftLabel)}</h5>${leftBody}</div>
        <div class="ev-pane"><h5>${UI.icon('table-2', 16)} ${UI.esc(rightLabel)}</h5>${rightBody}</div>
      </div>
    </div>
    <div class="ev-section">
      <h4>③ 影响与所需确认</h4>
      <div class="ev-impact" data-sev="${anomaly.severity}">
        ${impact.length ? impact.join('<br>') : '（本项为观察性提示，无金额影响）'}
      </div>
    </div>
    ${anomaly.resolved ? `<div class="ev-section"><h4>已裁决</h4><div class="ev-text">${
      UI.esc(anomaly.resolution ? `${anomaly.resolution.decision} · ${anomaly.resolution.operator} · ${anomaly.resolution.resolved_at}` : '')
    }</div></div>` : ''}`;
  UI.refreshIcons();
}

const ACTIONS = [
  { key: 'accept', label: '确认无误', icon: 'circle-check', cls: '', hint: '人工核实后认定该异常不成立，放行本项' },
  { key: 'override', label: '修正为某值', icon: 'pencil-line', cls: '', hint: '歧义匹配必须指定目标行；其余可填正确值' },
  { key: 'ignore', label: '打回重提', icon: 'undo-2', cls: 'btn-warn', hint: '退回发起人补充，本批次不得写入' },
];

function renderActions(state) {
  const host = document.getElementById('actions');
  const result = state.result;
  const anomaly = result && state.selectedId
    ? result.anomalies.find((a) => a.anomaly_id === state.selectedId)
    : null;
  if (!anomaly) {
    host.innerHTML = UI.emptyState('选择一项后可在此裁决。', 'gavel');
    return;
  }
  if (anomaly.resolved) {
    host.innerHTML = `<div class="toast" data-tone="ok">${UI.icon('circle-check', 16)}<span>该项已裁决，无需重复操作。</span></div>`;
    UI.refreshIcons();
    return;
  }
  const isAmbiguous = anomaly.code === 'MATCH_AMBIGUOUS';
  const candidates = isAmbiguous && anomaly.evidence_note
    ? (state.tableDetail ? state.tableDetail.rows
        .filter((r) => anomaly.evidence_note.indexOf(`第 ${r.row_ref} 行`) >= 0)
        .map((r) => ({ ref: r.row_ref, name: r.values.douyin_nickname, id: r.values.douyin_id }))
        : [])
    : [];

  host.innerHTML = ACTIONS.map((action) => {
    const disabled = isAmbiguous && action.key === 'accept';
    const title = disabled ? '歧义匹配不能用「确认无误」放行，请指定目标行或打回重提' : action.hint;
    return `<button class="btn ${action.cls}" data-action="${action.key}" type="button"
      ${disabled ? 'disabled' : ''} title="${UI.esc(title)}">
      ${UI.icon(action.icon, 20)}${UI.esc(action.label)}</button>`;
  }).join('') + `
    <div class="field">
      <label for="op">确认人</label>
      <input id="op" value="运营-小林" />
    </div>
    <div class="field">
      <label for="reason">理由 / 备注${anomaly.blocking ? '（打回重提必填）' : '（可选）'}</label>
      <input id="reason" placeholder="例：已与财务核对，按明细 5 笔入账" />
    </div>
    ${isAmbiguous ? `
    <div class="field">
      <label for="target">目标行（修正为某值时必填）</label>
      <select id="target">
        <option value="">请选择目标行</option>
        ${candidates.map((c) => `<option value="${UI.esc(c.ref)}">第 ${UI.esc(c.ref)} 行 · ${UI.esc(c.name)} · 抖音号 ${UI.esc(c.id || '（空）')}</option>`).join('')}
      </select>
    </div>` : `
    <div class="field">
      <label for="target">修正值（修正为某值时必填）</label>
      <input id="target" placeholder="例：2250 或 木木老师" />
    </div>`}
    <p class="fold-note">${UI.esc(anomaly.action_required || '需业务方确认')}</p>`;
  UI.refreshIcons();
}

function renderResolved(state) {
  const host = document.getElementById('resolved-box');
  if (!state.result) {
    host.innerHTML = '';
    return;
  }
  const done = state.result.anomalies.filter((a) => a.resolved);
  if (!done.length) {
    host.innerHTML = '<div>尚无已裁决记录。</div>';
    return;
  }
  host.innerHTML = `<div>已裁决 ${done.length} 项</div><ul>${done.slice(0, 6).map((a) =>
    `<li>${UI.esc(a.exc_id || a.code)} · ${UI.esc(a.resolution ? a.resolution.decision : '')} · ${UI.esc(a.resolution ? a.resolution.operator : '')}</li>`
  ).join('')}</ul>`;
}

function renderSummary(summary) {
  const grid = document.getElementById('summary-grid');
  const note = document.getElementById('summary-note');
  if (!summary) {
    grid.innerHTML = UI.emptyState('解析或写入后刷新，显示当日抖加与垫付金额。', 'sigma');
    note.textContent = '';
    return;
  }
  grid.innerHTML = summary.blocks.map((b) => {
    const label = b.biz_type === 'doujia' ? '抖加合计' : '垫付合计';
    const caliber = [
      { k: '文本声明额', v: b.declared_total_amount },
      { k: '明细求和', v: b.line_items_sum },
      { k: '表内该列累计', v: b.sheet_column_sum },
    ];
    return `<div class="summary-cell">
      <div class="label">${UI.icon('banknote', 16)} ${UI.esc(label)}</div>
      <div class="value">${UI.esc(UI.money(b.total_amount))}</div>
      <div class="sub">${UI.esc(b.entry_count)} 笔明细　${UI.esc(b.declared_count === null ? '—' : b.declared_count)} 笔声明</div>
      <div class="caliber">${caliber.map((c) =>
        `<div class="caliber-row"><span>${UI.esc(c.k)}</span><span class="num">${UI.esc(UI.money(c.v))}</span></div>`).join('')}</div>
    </div>`;
  }).join('');
  note.innerHTML = `<div class="side-note">${summary.blocks.map((b) => UI.esc(b.note)).join('<br>')}</div>`;
  UI.refreshIcons();
}

function renderReport(report) {
  const host = document.getElementById('report-host');
  if (!report) {
    host.innerHTML = UI.emptyState('生成后在此显示给负责人的简短汇报（结论 + 数字 + 需决策项）。', 'file-text');
    return;
  }
  host.innerHTML = `
    <div class="report-card">
      <h3>${UI.icon('file-text', 20)} 当日汇报 · ${UI.esc(report.date)}</h3>
      <p class="report-headline">${UI.esc(report.headline)}</p>
      <div class="report-numbers">
        <div><span class="label">抖加合计</span><span class="value">${UI.esc(UI.money(report.doujia_total))}</span></div>
        <div><span class="label">垫付合计</span><span class="value">${UI.esc(UI.money(report.advance_total))}</span></div>
        <div><span class="label">已确认金额</span><span class="value">${UI.esc(UI.money(report.confirmed_amount))}</span></div>
        <div><span class="label">待确认金额</span><span class="value">${UI.esc(UI.money(report.pending_amount))}</span></div>
      </div>
      ${report.decisions.length ? `<ul class="decision-list">${report.decisions.map((d) => `
        <li data-sev="${UI.esc(d.severity)}">${UI.sevPill(d.severity)}<span>${UI.esc(d.headline)}</span>
        <span class="need">${UI.esc(d.need_from)}</span></li>`).join('')}</ul>` :
        `<p class="fold-note">无待决策项。</p>`}
      ${report.overflow_count ? `<p class="fold-note">另有 ${report.overflow_count} 项，见裁决工作台。</p>` : ''}
      <div class="report-meta">数据来源：账号表测试副本（未触碰原表）　生成时间 ${UI.esc(report.generated_at || '')}</div>
      <div class="toolbar">
        <button class="btn" id="btn-copy-report" type="button">${UI.icon('copy', 16)}复制为文本</button>
        <button class="btn" id="btn-download-report" type="button">${UI.icon('download', 16)}下载 Markdown</button>
      </div>
    </div>`;
  UI.refreshIcons();
  const copy = document.getElementById('btn-copy-report');
  if (copy) copy.addEventListener('click', () => window.App.copyReport(report));
  const dl = document.getElementById('btn-download-report');
  if (dl) dl.addEventListener('click', () => window.App.downloadReport(report));
}

function renderLedger(state) {
  const host = document.getElementById('ledger-host');
  const parts = [];
  if (state.tableId) {
    parts.push(`<div>账号表测试副本：<span class="mono">${UI.esc(state.tableId)}</span>　` +
      `${UI.icon('file-stack', 16)} 源表只读，服务端复制后写入</div>`);
  }
  if (state.commitResult) {
    parts.push(`<div>上次写入：成功 ${UI.esc(state.commitResult.written_count)} 条，跳过 ${UI.esc(state.commitResult.skipped_count)} 条</div>`);
    const rows = state.commitResult.written.map((w) =>
      `<tr><td>${UI.esc(w.row_ref)}</td><td>${UI.esc(w.dedup_key)}</td><td>${UI.esc(Object.keys(w.fields_written).join('、') || '（仅溯源列）')}</td></tr>`).join('');
    if (rows) {
      parts.push(`<table class="sheet-table"><thead><tr><th>目标行</th><th>去重键</th><th>写入字段</th></tr></thead><tbody>${rows}</tbody></table>`);
    }
    const skipped = state.commitResult.skipped.map((s) => `${UI.esc(s.dedup_key)}（${UI.esc(s.reason)}）`).join('<br>');
    if (skipped) parts.push(`<div>跳过明细：<br>${skipped}</div>`);
  }
  if (state.decisions && state.decisions.length) {
    parts.push(`<details><summary>裁决日志（append-only，共 ${state.decisions.length} 条）</summary><pre>${UI.esc(JSON.stringify(state.decisions, null, 2))}</pre></details>`);
  }
  host.innerHTML = parts.length ? parts.join('') : UI.emptyState('写入副本后在此显示溯源信息与裁决日志。', 'scroll-text');
  UI.refreshIcons();
}

const Views = {
  renderStepper, renderCounts, renderMeta, renderQueue, renderEvidence,
  renderActions, renderResolved, renderSummary, renderReport, renderLedger, countBySeverity,
};
