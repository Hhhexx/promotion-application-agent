"""编排层：parse → validate → (review) → commit → summary → report（架构 §5.1）。

入口层只调用本层；本层不感知 HTTP。所有跨层数据都用 `app/domain/models.py` 的模型。
"""

from __future__ import annotations

from datetime import date as date_cls
from pathlib import Path

from app.core.config import DEFAULT_SOURCE_TABLE, TEST_COPY_DIR, ensure_dirs
from app.core.logging import log_event
from app.domain.enums import AnomalyCode, ItemState
from app.domain.errors import (
    DomainError,
    GateBlockedError,
    NotFoundError,
    ValidationError,
)
from app.domain.models import (
    AccountTableDetail,
    AccountTableMeta,
    CommitResult,
    DailyReport,
    DailySummary,
    ParseResult,
    SkippedEntry,
    WrittenEntry,
)
from app.llm.llm_adapter import reset_adapter
from app.parsers.base import parse_request
from app.repositories.memory_store import STORE, MemoryStore, TableRecord
from app.repositories.xlsx_repository import (
    TableSnapshot,
    XlsxRepository,
    copy_test_copy,
    utc_now_iso,
)
from app.reporters.report_builder import build_report
from app.reporters.summary_service import build_summary
from app.validators.anomaly_rules import AnomalyFactory
from app.validators.engine import validate
from app.orchestrator.review_gate import apply_item_states, open_blockers

#: `AFTER_DECISION` 列的允许取值来源 —— 文本未声明的字段一律不写。
ADVANCE_PENDING_NOTE = "是否打款=未写入（文本仅声明垫付申请与预计打款日期，系统不推断已打款）"


def _store() -> MemoryStore:
    return STORE


# --------------------------------------------------------------------------- #
# 账号表
# --------------------------------------------------------------------------- #
def register_table(
    source_path: str | Path | None = None,
    filename: str | None = None,
) -> AccountTableMeta:
    """登记账号表：**复制为测试副本**，源表只读（架构 §3.2）。"""
    ensure_dirs()
    store = _store()
    source = Path(source_path) if source_path else DEFAULT_SOURCE_TABLE
    if not source.exists():
        raise ValidationError(f"账号表源文件不存在：{source}")
    table_id = f"tbl_copy_{store.next_seq('table'):02d}"
    copy_path = TEST_COPY_DIR / f"{table_id}__{source.stem}（测试副本）.xlsx"
    copy_test_copy(source, copy_path)
    repo = XlsxRepository(copy_path)
    snapshot = repo.snapshot()
    meta = AccountTableMeta(
        table_id=table_id,
        filename=filename or copy_path.name,
        row_count=len(snapshot.rows),
        is_test_copy=True,
        source_path=str(source),
        copy_path=str(copy_path),
    )
    store.put_table(TableRecord(meta=meta, source_path=str(source), copy_path=str(copy_path)))
    log_event("table_registered", table_id=table_id, rows=len(snapshot.rows), source=str(source))
    return meta


def table_detail(table_id: str) -> AccountTableDetail:
    record = _require_table(table_id)
    repo = XlsxRepository(record.copy_path)
    snapshot = repo.snapshot()
    meta = record.meta
    return AccountTableDetail(
        **meta.model_dump(),
        columns=snapshot.columns,
        rows=[{"row_ref": r.row_ref, **{k: _jsonable(v) for k, v in r.values.items()}} for r in snapshot.rows],
        empty_row_refs=snapshot.empty_row_refs,
    )


def table_snapshot(table_id: str | None = None) -> TableSnapshot:
    """读取账号表快照（用于裁决时重跑字段冲突校验）。未指定则用当前默认表。"""
    store = _store()
    record = _require_table(table_id) if table_id else store.default_table()
    if record is None:
        raise NotFoundError("尚未登记账号表")
    return XlsxRepository(record.copy_path).snapshot()


def _require_table(table_id: str):
    record = _store().get_table(table_id)
    if record is None:
        raise NotFoundError(f"账号表 {table_id} 未登记")
    return record


def _jsonable(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


# --------------------------------------------------------------------------- #
# 解析
# --------------------------------------------------------------------------- #
def parse_into_request(
    raw_text: str,
    biz_type_hint=None,
    table_id: str | None = None,
    enable_llm: bool = False,
) -> ParseResult:
    """解析 + 校验。存在 P0 时批次进入 NEEDS_REVIEW 并禁止写表。"""
    store = _store()
    record = _require_table(table_id) if table_id else store.default_table()
    if record is None:
        record = _auto_register_default()
    if enable_llm:
        reset_adapter()
    parsed = parse_request(raw_text, biz_type_hint)
    request_id = f"req_{parsed.declared_date.strftime('%Y%m%d')}_{parsed.biz_type.value}_{store.next_seq('req'):02d}"
    snapshot = XlsxRepository(record.copy_path).snapshot()
    result = validate(parsed, snapshot, request_id)
    result.table_id = record.meta.table_id
    apply_item_states(result)
    store.put_request(result)
    log_event(
        "request_parsed",
        request_id=request_id,
        biz=parsed.biz_type.value,
        items=len(result.line_items),
        p0=len(open_blockers(result)),
        anomalies=len(result.anomalies),
    )
    return result


def _auto_register_default() -> TableRecord:
    """未显式上传时自动登记仓库自带的测试用账号表。"""
    if not DEFAULT_SOURCE_TABLE.exists():
        raise NotFoundError("尚未登记账号表，且仓库内无默认测试表")
    register_table()
    record = _store().default_table()
    assert record is not None
    return record


def get_request(request_id: str) -> ParseResult:
    result = _store().get_request(request_id)
    if result is None:
        raise NotFoundError(f"请求 {request_id} 不存在")
    return result


# --------------------------------------------------------------------------- #
# 写表
# --------------------------------------------------------------------------- #
def commit_request(request_id: str, table_id: str) -> CommitResult:
    """把已确认条目写入测试副本（幂等）。

    **闸门不变量**：存在未裁决 P0 或被打回项时抛 `GateBlockedError`，
    调用方映射 HTTP 409，且本函数在抛错前**不打开工作簿**——不发生任何写入。
    """
    store = _store()
    result = get_request(request_id)
    record = _require_table(table_id)
    # 行号（row_ref）只在「解析时所用的那张表」上有意义。
    # 若允许换表写表，就会把 A 表的行号写到 B 表的同名行上——契约破坏。
    if result.table_id and result.table_id != table_id:
        raise ValidationError(
            f"申请 {request_id} 是依据账号表 {result.table_id} 校验的，"
            f"不能用 {table_id} 写表；请重新解析或改用同一张表"
        )

    apply_item_states(result)
    blocked = open_blockers(result)
    if result.aggregate_state is not ItemState.READY:
        reason = "存在未裁决阻断项" if blocked else "存在被打回重提的阻断项"
        raise GateBlockedError(
            f"{reason}，禁止写入测试副本",
            pending=[a.anomaly_id for a in blocked],
        )

    has_decision = _has_batch_decision(result)
    repo = XlsxRepository(record.copy_path)
    ledger = repo.ledger_keys()
    written: list[WrittenEntry] = []
    skipped: list[SkippedEntry] = []
    ledger_entries: list[dict] = []
    now = utc_now_iso()

    for item in result.line_items:
        if item.state is not ItemState.READY:
            skipped.append(SkippedEntry(dedup_key=item.dedup_key, reason="NOT_READY"))
            continue
        if item.dedup_key in ledger:
            item.state = ItemState.SKIPPED_ALREADY_WRITTEN
            skipped.append(SkippedEntry(dedup_key=item.dedup_key, reason="SKIPPED_ALREADY_WRITTEN"))
            continue
        writes, note = _plan_writes(result, item, has_decision)
        row_ref = item.match_result.matched_row_ref if item.match_result else None
        if row_ref is None:
            skipped.append(SkippedEntry(dedup_key=item.dedup_key, reason="NOT_READY"))
            continue
        trace = {
            "_batch_id": result.batch_id,
            "_request_id": result.request_id,
            "_rule_id": "write.plan",
            "_confirmed_by": _confirmed_by(result, item.line_no),
            "_confirmed_at": now,
            "_dedup_key": item.dedup_key,
        }
        remark = f"来源={result.batch_id}；request_id={result.request_id}；{note}"
        cells, blocked_cells = repo.write_row(row_ref, writes, trace, remark=remark)
        if blocked_cells:
            factory = AnomalyFactory(prefix=f"anmW{item.line_no}")
            for key, existing in blocked_cells:
                result.anomalies.append(
                    factory.make(
                        AnomalyCode.TARGET_CELL_NONEMPTY,
                        f"「{item.blogger_name_raw}」第 {row_ref} 行目标单元格已有值「{existing}」，未覆盖",
                        line_no=item.line_no,
                        account_ref=item.blogger_name_raw,
                        sheet_row_ref=row_ref,
                        target_field=key,
                        sheet_value=existing,
                        action_required="需运营确认以哪一侧为准；系统不覆盖已有值",
                    )
                )
        if cells or not writes:
            item.state = ItemState.WRITTEN
            written.append(
                WrittenEntry(dedup_key=item.dedup_key, row_ref=row_ref, fields_written=cells)
            )
            ledger_entries.append(
                {
                    "dedup_key": item.dedup_key,
                    "batch_id": result.batch_id,
                    "request_id": result.request_id,
                    "row_ref": row_ref,
                    "written_at": now,
                }
            )

    if ledger_entries:
        repo.append_ledger(ledger_entries)
        repo.save()
    outcome = CommitResult(
        written_count=len(written), skipped_count=len(skipped), written=written, skipped=skipped
    )
    store.commits[request_id] = outcome
    log_event(
        "commit_done",
        request_id=request_id,
        written=len(written),
        skipped=len(skipped),
        copy=record.copy_path,
    )
    return outcome


def _has_batch_decision(result: ParseResult) -> bool:
    """`AFTER_DECISION` 列的写入前置条件之一：本批次存在 accept/override 裁决，或初始无 P0。"""
    if any(a.resolution is not None and a.resolution.decision in ("accept", "override") for a in result.anomalies):
        return True
    return not any(a.blocking for a in result.anomalies)


def _confirmed_by(result: ParseResult, line_no: int | None) -> str:
    for anomaly in result.anomalies:
        if anomaly.resolution is None or anomaly.line_no != line_no:
            continue
        return anomaly.resolution.operator
    for anomaly in result.anomalies:
        if anomaly.resolution is not None and anomaly.resolution.decision in ("accept", "override"):
            return anomaly.resolution.operator
    return "（本批次初始校验通过）"


def _plan_writes(result: ParseResult, item, has_decision: bool) -> tuple[dict, str]:
    """按回填权限表规划写入内容。**不写任何文本未声明的字段。**"""
    biz = item.biz_type.value if hasattr(item.biz_type, "value") else str(item.biz_type)
    writes: dict[str, object] = {}
    notes: list[str] = []
    if biz == "doujia":
        writes["doujia_amount"] = item.amount_exact or f"{item.amount:.2f}"
        writes["doujia_payer"] = item.payer
        notes.append(f"抖加金额与支付人来自 {result.batch_id}")
    else:
        if not has_decision:
            return {}, "无人工裁决记录，跳过「人工确认后才可写」列"
        writes["payer"] = item.payer
        if result.summary.expected_pay_date is not None:
            writes["pay_date"] = result.summary.expected_pay_date.isoformat()
            notes.append(f"打款日期取文本「预计打款日期」{result.summary.expected_pay_date_raw}")
        notes.append(ADVANCE_PENDING_NOTE)
    return writes, "；".join(notes)


# --------------------------------------------------------------------------- #
# 汇总与汇报
# --------------------------------------------------------------------------- #
def daily_summary(date: date_cls, biz_type=None) -> DailySummary:
    return build_summary(_store(), date, biz_type)


def create_daily_report(date: date_cls, include_unresolved: bool = True) -> DailyReport:
    store = _store()
    report = build_report(store, date, include_unresolved=include_unresolved)
    store.put_report(report)
    return report


def get_daily_report(report_id: str) -> DailyReport:
    report = _store().get_report(report_id)
    if report is None:
        raise NotFoundError(f"汇报 {report_id} 不存在")
    return report


__all__ = [
    "register_table",
    "table_detail",
    "table_snapshot",
    "parse_into_request",
    "get_request",
    "commit_request",
    "daily_summary",
    "create_daily_report",
    "get_daily_report",
    "DomainError",
]
