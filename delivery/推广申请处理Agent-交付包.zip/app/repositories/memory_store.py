"""内存态存储（架构 §5.5 演示态：内存为主 + 裁决日志落 JSONL）。

**不引入数据库**（ADR-003）。主数据在内存，产物落文件。
所有写入只作用于测试副本；源表路径仅作只读引用保存。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.domain.models import (
    AccountTableMeta,
    CommitResult,
    DailyReport,
    ParseResult,
    Resolution,
)


@dataclass
class TableRecord:
    """一张已登记账号表的运行期句柄。"""

    meta: AccountTableMeta
    source_path: str
    copy_path: str
    is_test_copy: bool = True


@dataclass
class MemoryStore:
    """进程内主数据存储。测试可调用 `reset()` 获得干净状态。"""

    tables: dict[str, TableRecord] = field(default_factory=dict)
    requests: dict[str, ParseResult] = field(default_factory=dict)
    reports: dict[str, DailyReport] = field(default_factory=dict)
    commits: dict[str, CommitResult] = field(default_factory=dict)
    decisions: dict[str, Resolution] = field(default_factory=dict)
    decision_log: list[dict] = field(default_factory=list)
    counters: dict[str, int] = field(default_factory=dict)

    # ------------------------------------------------------------- 表
    def put_table(self, record: TableRecord) -> None:
        self.tables[record.meta.table_id] = record

    def get_table(self, table_id: str) -> TableRecord | None:
        return self.tables.get(table_id)

    def default_table(self) -> TableRecord | None:
        if not self.tables:
            return None
        return next(iter(self.tables.values()))

    # --------------------------------------------------------- 请求
    def put_request(self, result: ParseResult) -> None:
        self.requests[result.request_id] = result

    def get_request(self, request_id: str) -> ParseResult | None:
        return self.requests.get(request_id)

    # --------------------------------------------------------- 裁决
    def put_decision(self, request_id: str, anomaly_id: str, resolution: Resolution) -> None:
        self.decisions[f"{request_id}:{anomaly_id}"] = resolution

    def get_decision(self, request_id: str, anomaly_id: str) -> Resolution | None:
        return self.decisions.get(f"{request_id}:{anomaly_id}")

    def line_has_decision(self, request_id: str, line_no: int) -> bool:
        """该条目是否已有 accept/override 记录 —— `AFTER_DECISION` 列的写入前置条件。"""
        prefix = f"{request_id}:"
        for key, res in self.decisions.items():
            if not key.startswith(prefix) or res.decision not in ("accept", "override"):
                continue
            if res.note and res.note.startswith(f"line:{line_no}|"):
                return True
        return False

    def append_log(self, entry: dict) -> None:
        self.decision_log.append(entry)

    # --------------------------------------------------------- 汇报
    def put_report(self, report: DailyReport) -> None:
        self.reports[report.report_id] = report

    def get_report(self, report_id: str) -> DailyReport | None:
        return self.reports.get(report_id)

    # --------------------------------------------------------- 序号
    def next_seq(self, key: str) -> int:
        self.counters[key] = self.counters.get(key, 0) + 1
        return self.counters[key]

    def reset(self) -> None:
        self.tables.clear()
        self.requests.clear()
        self.reports.clear()
        self.commits.clear()
        self.decisions.clear()
        self.decision_log.clear()
        self.counters.clear()


#: 进程级单例（演示态；测试通过 fixture 调用 `reset()`）。
STORE = MemoryStore()
