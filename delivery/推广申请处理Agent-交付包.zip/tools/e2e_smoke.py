"""端到端冒烟验证（对应 Spec v1.0 §12 端到端验证步骤）。

不启动真实端口，直接用 TestClient 走完整链路：
  健康检查 -> 登记账号表 -> 解析抖加（期望 0 个 P0）-> 解析垫付（期望 3 个 P0）
  -> 写表应被 409 拦截 -> 逐条裁决 -> 写表成功 -> 幂等重放全 SKIPPED
  -> 当日汇总 -> 负责人汇报 -> 裁决日志导出 -> 源表零污染的字节级校验

用法：
  <venv>/python.exe tools/e2e_smoke.py
退出码 0 = 全绿；1 = 存在断言失败。
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

SOURCE = ROOT / "data" / "你是我的仰望-推广账号表.xlsx"
DOUJIA = ROOT / "data" / "samples" / "抖加申请-2026-09-02.txt"
ADVANCE = ROOT / "data" / "samples" / "垫付申请-2026-09-03.txt"

_failures: list[str] = []
_checks = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global _checks
    _checks += 1
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
    if not condition:
        _failures.append(label)


def title(text: str) -> None:
    print(f"\n=== {text} ===")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


#: 表头中文名 -> API 返回的行字段名（与 app/repositories/sheet_schema.py 对齐）
HEADER_TO_KEY = {
    "类型": "type",
    "抖音昵称": "douyin_nickname",
    "抖音号": "douyin_id",
    "报价": "quote_price",
    "抖加": "doujia_amount",
    "抖加支付人": "doujia_payer",
    "是否打款": "is_paid",
    "打款人": "payer",
    "打款日期": "pay_date",
    "发布日期": "publish_date",
    "是否接单": "accepted",
    "审核结果": "review_result",
    "备注": "remark",
}


def _norm_cell(value) -> str:
    """把 Excel 单元格值归一为可比较字符串（1 vs 1.0、None vs "" 视为相同）。"""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def read_source_rows(path: Path) -> dict[str, dict]:
    """用 openpyxl 直读源表，返回 {行号: {表头: 原始值}}。"""
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    out: dict[str, dict] = {}
    for idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        if all(v is None or str(v).strip() == "" for v in row):
            continue
        out[str(idx)] = {headers[i]: row[i] for i in range(min(len(headers), len(row)))}
    wb.close()
    return out


def anomalies_of(payload: dict) -> list[dict]:
    return (payload.get("data") or {}).get("anomalies") or []


def p0_of(payload: dict) -> list[dict]:
    return [a for a in anomalies_of(payload) if a.get("severity") == "P0"]


def by_code(payload: dict, code: str) -> list[dict]:
    return [a for a in anomalies_of(payload) if a.get("code") == code]


def one(items: list[dict]) -> dict:
    return items[0] if items else {}


def main() -> int:
    source_hash_before = sha256(SOURCE)

    # 干净起点：清掉历史副本与裁决日志，保证断言可重复
    shutil.rmtree(ROOT / "data" / "test-copies", ignore_errors=True)
    shutil.rmtree(ROOT / "data" / "decisions", ignore_errors=True)
    shutil.rmtree(ROOT / "data" / "uploads", ignore_errors=True)

    with TestClient(app) as client:
        title("1. 健康检查")
        r = client.get("/health")
        check("GET /health 返回 200", r.status_code == 200, str(r.status_code))
        check("健康体 status=ok", (r.json() or {}).get("status") == "ok")

        r = client.get("/")
        check("GET / 返回前端页面", r.status_code == 200 and "<html" in r.text.lower(), str(r.status_code))
        r = client.get("/docs")
        check("GET /docs 返回接口文档", r.status_code == 200, str(r.status_code))

        title("2. 登记账号表（服务端复制副本，源表只读）")
        r = client.post("/api/v1/account-tables")
        check("POST /account-tables 返回 201", r.status_code == 201, str(r.status_code))
        meta = (r.json() or {}).get("data") or {}
        table_id = meta.get("table_id") or ""
        check("拿到 table_id", bool(table_id), table_id)
        copy_path = Path(meta.get("copy_path") or "")
        check("副本文件已落盘", copy_path.exists(), str(copy_path))
        check("副本 ≠ 源表路径", copy_path.resolve() != SOURCE.resolve())
        check("副本被标记 is_test_copy", meta.get("is_test_copy") is True)
        check("源表字节未被改动", sha256(SOURCE) == source_hash_before)

        title("3. 解析抖加申请（期望 0 个 P0）")
        r = client.post(
            "/api/v1/requests/parse",
            json={"raw_text": DOUJIA.read_text(encoding="utf-8"), "table_id": table_id},
        )
        check("POST /requests/parse 返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        dj = r.json()
        dj_data = dj.get("data") or {}
        dj_id = dj_data.get("request_id") or ""
        check("拿到 request_id", bool(dj_id), dj_id)
        check("request_id 含业务与日期", "20260902" in dj_id and "doujia" in dj_id, dj_id)
        check("抖加 P0 数量为 0", len(p0_of(dj)) == 0, json.dumps(p0_of(dj), ensure_ascii=False)[:200])
        check(
            "声明总额 700.00",
            (dj_data.get("summary") or {}).get("declared_total_exact") == "700.00",
            str((dj_data.get("summary") or {}).get("declared_total_exact")),
        )
        check(
            "明细行金额之和 = 700",
            (dj_data.get("cross_check") or {}).get("line_items_sum") == 700.0,
            str((dj_data.get("cross_check") or {}).get("line_items_sum")),
        )
        check(
            "合并同博主后 4 行明细",
            len(dj_data.get("line_items") or []) == 4,
            str(len(dj_data.get("line_items") or [])),
        )
        check(
            "拆笔数之和 7 与声明笔数一致",
            (dj_data.get("cross_check") or {}).get("split_count_sum")
            == (dj_data.get("cross_check") or {}).get("declared_count"),
            json.dumps(dj_data.get("cross_check"), ensure_ascii=False)[:160],
        )
        cross_mismatch = by_code(dj, "CROSS_SOURCE_TOTAL_MISMATCH")
        check(
            "跨源口径不一致降级为 P1（不阻断）",
            len(cross_mismatch) >= 1
            and all(a.get("severity") == "P1" and not a.get("blocking") for a in cross_mismatch),
            f"{len(cross_mismatch)} 条",
        )
        check(
            "表内抖加列合计 400（第三口径可见）",
            (dj_data.get("cross_check") or {}).get("sheet_column_sum") == 400.0,
            str((dj_data.get("cross_check") or {}).get("sheet_column_sum")),
        )
        check(
            "汇总口径明确不合并为一个数字",
            (dj_data.get("cross_check") or {}).get("line_items_sum")
            != (dj_data.get("cross_check") or {}).get("sheet_column_sum"),
        )
        check("批次状态为 READY", dj_data.get("aggregate_state") == "READY", str(dj_data.get("aggregate_state")))

        title("4. 抖加批次写表（无 P0 应直接放行）")
        r = client.post(f"/api/v1/requests/{dj_id}/commit", json={"table_id": table_id})
        check("写表返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        dj_commit = (r.json() or {}).get("data") or {}
        check("写入 4 行", dj_commit.get("written_count") == 4, str(dj_commit.get("written_count")))
        check("跳过 0 行", dj_commit.get("skipped_count") == 0, str(dj_commit.get("skipped_count")))
        dj_rows = [w.get("row_ref") for w in (dj_commit.get("written") or [])]
        check("落点行号为 2/3/4/5", sorted(dj_rows) == ["2", "3", "4", "5"], str(dj_rows))
        first_fields = ((dj_commit.get("written") or [{}])[0].get("fields_written") or {})
        check("写了抖加金额列", "doujia_amount" in first_fields, str(list(first_fields)))
        check("写了抖加支付人列", "doujia_payer" in first_fields, str(list(first_fields)))
        check("备注列写明来源批次", "来源=" in (first_fields.get("remark") or ""), str(first_fields.get("remark"))[:80])
        check("报价列未被改写（只读）", "quote_price" not in first_fields, str(list(first_fields)))

        title("5. 幂等重放（同批次再写应全部 SKIPPED 且不改表）")
        copy_hash_after_dj = sha256(copy_path)
        r = client.post(f"/api/v1/requests/{dj_id}/commit", json={"table_id": table_id})
        replay = (r.json() or {}).get("data") or {}
        check("重放返回 200", r.status_code == 200, str(r.status_code))
        check("重放写入 0 行", replay.get("written_count") == 0, str(replay.get("written_count")))
        check("重放跳过 4 行", replay.get("skipped_count") == 4, str(replay.get("skipped_count")))
        check(
            "跳过原因为 SKIPPED_ALREADY_WRITTEN",
            all(s.get("reason") == "SKIPPED_ALREADY_WRITTEN" for s in (replay.get("skipped") or [])),
            json.dumps(replay.get("skipped"), ensure_ascii=False)[:200],
        )
        check("重放未改动副本字节", sha256(copy_path) == copy_hash_after_dj)

        title("6. 解析垫付申请（期望 3 个 P0）")
        r = client.post(
            "/api/v1/requests/parse",
            json={"raw_text": ADVANCE.read_text(encoding="utf-8"), "table_id": table_id},
        )
        check("POST /requests/parse 返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        adv = r.json()
        adv_data = adv.get("data") or {}
        adv_id = adv_data.get("request_id") or ""
        adv_p0 = p0_of(adv)
        check("垫付 P0 数量为 3", len(adv_p0) == 3, f"实际 {len(adv_p0)}: {[a.get('code') for a in adv_p0]}")
        for code in ("COUNT_MISMATCH", "DATE_ORDER_INVALID", "MATCH_AMBIGUOUS"):
            check(f"命中 P0 异常码 {code}", len(by_code(adv, code)) == 1, str(len(by_code(adv, code))))
        check("P0 均标记 blocking", all(a.get("blocking") for a in adv_p0))
        check(
            "闸门状态为 NEEDS_REVIEW",
            adv_data.get("aggregate_state") == "NEEDS_REVIEW",
            str(adv_data.get("aggregate_state")),
        )
        check("所有 P0 带 anomaly_id", all(a.get("anomaly_id") for a in adv_p0))
        check(
            "声明垫付总额 2250.00",
            (adv_data.get("summary") or {}).get("declared_total_exact") == "2250.00",
            str((adv_data.get("summary") or {}).get("declared_total_exact")),
        )

        title("6.1 异常必须给出可核查的证据与动作，而不是一句「有问题」")
        for anomaly in adv_p0:
            check(
                f"{anomaly.get('code')} 带 evidence/action/suggestion",
                bool(anomaly.get("message"))
                and bool(anomaly.get("action_required") or anomaly.get("suggestion"))
                and bool(anomaly.get("rule_id"))
                and bool(anomaly.get("exc_id")),
                f"rule={anomaly.get('rule_id')} exc={anomaly.get('exc_id')}",
            )
        check(
            "全部 15 条异常都带 PRD 编号（便于对照产品文档）",
            all(a.get("exc_id") for a in anomalies_of(adv)),
            str([a.get("exc_id") for a in anomalies_of(adv)]),
        )
        check(
            "异常分级覆盖 P0/P1/P2 三档",
            {a.get("severity") for a in anomalies_of(adv)} == {"P0", "P1", "P2"},
            str(sorted({a.get("severity") for a in anomalies_of(adv)})),
        )
        check(
            "台账里已有的问题（空行/日期格式/昵称脏/未接单）被标记为 P1/P2 不阻断",
            all(
                a.get("severity") in ("P1", "P2")
                for a in anomalies_of(adv)
                if a.get("code")
                in (
                    "TABLE_EMPTY_ROW_SKIPPED",
                    "DATE_FORMAT_INCONSISTENT",
                    "NICKNAME_DIRTY",
                    "DOUJIA_EXCEEDS_QUOTE",
                    "UNACCEPTED_WITH_AMOUNT",
                )
            ),
        )

        title("7. 未裁决时写表必须被 409 拦截（且零写入）")
        copy_hash_before_block = sha256(copy_path)
        r = client.post(f"/api/v1/requests/{adv_id}/commit", json={"table_id": table_id})
        body = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        check("写表返回 409", r.status_code == 409, f"{r.status_code} {r.text[:200]}")
        check("响应体 code 非 0", body.get("code") != 0, str(body.get("code")))
        check("响应体回传 pending 异常 id", len((body.get("data") or {}).get("pending") or []) == 3, json.dumps(body.get("data"), ensure_ascii=False)[:160])
        check("拦截时副本字节未变动", sha256(copy_path) == copy_hash_before_block)

        title("8. 错误裁决动作必须被拒绝（歧义不能用「确认无误」放行）")
        ambiguous = one(by_code(adv, "MATCH_AMBIGUOUS"))
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={"anomaly_id": ambiguous.get("anomaly_id"), "decision": "accept", "operator": "e2e"},
        )
        check("歧义 + accept 返回 409", r.status_code == 409, f"{r.status_code} {r.text[:160]}")
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={"anomaly_id": ambiguous.get("anomaly_id"), "decision": "override", "operator": "e2e"},
        )
        check("override 缺修正值返回 4xx", 400 <= r.status_code < 500, f"{r.status_code} {r.text[:160]}")
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={"anomaly_id": "anm_not_exist", "decision": "accept", "operator": "e2e"},
        )
        check("不存在的异常 id 返回 404", r.status_code == 404, str(r.status_code))

        title("9. 逐条人工裁决，闸门应逐步收敛")
        # 9.1 笔数不一致：以明细为准
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={
                "anomaly_id": one(by_code(adv, "COUNT_MISMATCH")).get("anomaly_id"),
                "decision": "accept",
                "operator": "e2e",
                "note": "已与发起人核对，以明细 6 笔为准",
            },
        )
        check("COUNT_MISMATCH 裁决返回 200", r.status_code == 200, f"{r.status_code} {r.text[:160]}")
        if r.status_code == 200:
            check("裁决后仍剩 2 个 P0", ((r.json().get("data") or {}).get("remaining_p0_count")) == 2, str((r.json().get("data") or {}).get("remaining_p0_count")))

        # 9.2 日期倒挂：确认为录入笔误
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={
                "anomaly_id": one(by_code(adv, "DATE_ORDER_INVALID")).get("anomaly_id"),
                "decision": "accept",
                "operator": "e2e",
                "note": "确认打款日期栏为录入笔误",
            },
        )
        check("DATE_ORDER_INVALID 裁决返回 200", r.status_code == 200, f"{r.status_code} {r.text[:160]}")
        if r.status_code == 200:
            check("裁决后仍剩 1 个 P0", ((r.json().get("data") or {}).get("remaining_p0_count")) == 1, str((r.json().get("data") or {}).get("remaining_p0_count")))

        # 9.3 匹配歧义（葵花夫妇命中 2 行）→ 从条目的 match_result.candidates 取候选行
        ambiguous_item = next(
            (i for i in (adv_data.get("line_items") or []) if (i.get("match_result") or {}).get("level") == "AMBIGUOUS"),
            None,
        )
        check("找到 AMBIGUOUS 明细行", ambiguous_item is not None)
        candidates = ((ambiguous_item or {}).get("match_result") or {}).get("candidates") or []
        check("候选行 >= 2", len(candidates) >= 2, str([c.get("row_ref") for c in candidates]))
        pick = one(candidates).get("row_ref")
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={
                "anomaly_id": ambiguous.get("anomaly_id"),
                "decision": "override",
                "override_value": str(pick),
                "operator": "e2e",
                "note": f"人工核对后指定第 {pick} 行",
            },
        )
        check("MATCH_AMBIGUOUS override 返回 200", r.status_code == 200, f"{r.status_code} {r.text[:160]}")
        if r.status_code == 200:
            outcome = r.json().get("data") or {}
            check("重跑校验已执行", outcome.get("revalidated") is True)
            check(
                "钉死目标行后暴露出新的 P0（信息不丢失）",
                (outcome.get("remaining_p0_count") or 0) == 1,
                f"remaining={outcome.get('remaining_p0_count')} still_blocking={outcome.get('still_blocking')}",
            )
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={"anomaly_id": ambiguous.get("anomaly_id"), "decision": "override", "override_value": "99999", "operator": "e2e"},
        )
        check("指定不存在的行号被拒绝", 400 <= r.status_code < 500, str(r.status_code))

        title("9.4 把重跑暴露出的字段冲突也裁掉（否则应一直卡在 NEEDS_REVIEW）")
        r = client.get(f"/api/v1/requests/{adv_id}")
        surfaced = [
            a
            for a in ((r.json().get("data") or {}).get("anomalies") or [])
            if a.get("severity") == "P0" and not a.get("resolved")
        ]
        check("暴露出的 P0 恰好 1 条", len(surfaced) == 1, json.dumps([a.get("code") for a in surfaced], ensure_ascii=False))
        surfaced_one = one(surfaced)
        check(
            "冲突异常写明「文本值 vs 台账值」两侧取值",
            bool(surfaced_one.get("text_value")) and bool(surfaced_one.get("sheet_value")),
            f"{surfaced_one.get('text_value')} vs {surfaced_one.get('sheet_value')}",
        )
        # 人工判定：台账已有打款记录，以台账为准 → 不接受文本侧改值
        r = client.post(
            f"/api/v1/requests/{adv_id}/resolutions",
            json={
                "anomaly_id": surfaced_one.get("anomaly_id"),
                "decision": "accept",
                "operator": "e2e",
                "note": "台账第 7 行已有打款记录，以台账为准，本批次不改写",
            },
        )
        check("冲突裁决返回 200", r.status_code == 200, f"{r.status_code} {r.text[:160]}")
        if r.status_code == 200:
            check(
                "剩余 P0 归零",
                ((r.json().get("data") or {}).get("remaining_p0_count") or 0) == 0,
                str((r.json().get("data") or {}).get("remaining_p0_count")),
            )

        title("10. 裁决后写表应放行")
        r = client.get(f"/api/v1/requests/{adv_id}")
        check("重取申请返回 200", r.status_code == 200, str(r.status_code))
        after = (r.json() or {}).get("data") or {}
        check("闸门状态转为 READY", after.get("aggregate_state") == "READY", str(after.get("aggregate_state")))
        check("异常已标记 resolved", all(a.get("resolved") for a in (after.get("anomalies") or []) if a.get("severity") == "P0"))

        r = client.post(f"/api/v1/requests/{adv_id}/commit", json={"table_id": table_id})
        check("写表返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        adv_commit = (r.json() or {}).get("data") or {}
        check("写入了 5 行", adv_commit.get("written_count") == 5, str(adv_commit.get("written_count")))
        adv_rows = [w.get("row_ref") for w in (adv_commit.get("written") or [])]
        check("葵花夫妇落点 = 人工指定的行", str(pick) in adv_rows, f"pick={pick} rows={adv_rows}")

        title("11. 换表写表必须被拒绝（行号只在解析所用的表上有意义）")
        other = client.post("/api/v1/account-tables").json()["data"]["table_id"]
        r = client.post(f"/api/v1/requests/{adv_id}/commit", json={"table_id": other})
        check("跨表写表返回 4xx", 400 <= r.status_code < 500, f"{r.status_code} {r.text[:160]}")

        title("12. 写入内容核查（回填权限表 + 不猜测填充）")
        r = client.get(f"/api/v1/account-tables/{table_id}")
        check("GET /account-tables 返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        detail = (r.json() or {}).get("data") or {}
        check("返回列名清单", len(detail.get("columns") or []) == 13, str(detail.get("columns")))
        rows = {str(row.get("row_ref")): row for row in (detail.get("rows") or [])}
        check("副本中空行被登记（第 12 行）", "12" in (detail.get("empty_row_refs") or []), str(detail.get("empty_row_refs")))

        written_rows = [r_ for r_ in (adv_commit.get("written") or [])]
        check(
            "写入行的备注列带来源批次标记",
            all(
                "来源=" in (rows.get(str(w.get("row_ref")), {}).get("remark") or "")
                for w in written_rows
            ),
        )
        untouched = rows.get("4", {})
        check(
            "只被抖加批次覆盖的行，垫付列未被抖加批次动过",
            untouched.get("doujia_amount") == "100.00"
            and (untouched.get("doujia_payer") or "") == "爆火音乐",
            json.dumps(untouched, ensure_ascii=False)[:260],
        )
        adv_row = rows.get(str(pick), {})
        check(
            "人工指定的目标行拿到了垫付列写入",
            (adv_row.get("pay_date") or "") != "" or (adv_row.get("payer") or "") != "",
            json.dumps(adv_row, ensure_ascii=False)[:260],
        )

        # 强断言：逐行逐列比对副本 vs 源表 —— 除了本批次允许写的列，
        # 其余列必须与源表取值完全一致（证明写入没有"顺手改别的列"）。
        src_rows = read_source_rows(SOURCE)
        writable_headers = {"抖加", "抖加支付人", "打款人", "打款日期", "备注"}
        diffs: list[str] = []
        for row_ref, src_row in src_rows.items():
            copy_row = rows.get(row_ref, {})
            for header, src_value in src_row.items():
                if header in writable_headers:
                    continue
                key = HEADER_TO_KEY.get(header)
                if key is None:
                    continue
                got = copy_row.get(key)
                if _norm_cell(got) != _norm_cell(src_value):
                    diffs.append(f"第{row_ref}行 {header}: 源={src_value!r} 副本={got!r}")
        check(
            "非授权列逐行逐列与源表一致（写入未越界）",
            not diffs,
            "；".join(diffs[:4]),
        )
        check("源表字节仍未改动", sha256(SOURCE) == source_hash_before, "源表被污染！")

        title("13. 当日汇总（三口径并列，不合并）")
        r = client.get("/api/v1/summary", params={"date": "2026-09-02", "biz_type": "doujia"})
        check("GET /summary 返回 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
        summary = (r.json() or {}).get("data") or {}
        blocks = summary.get("blocks") or []
        check("返回单一业务口径块", len(blocks) == 1, str(len(blocks)))
        block = one(blocks)
        check("抖加口径块 total_amount = 700", block.get("total_amount") == 700.0, str(block.get("total_amount")))
        check("口径块同时列出声明值与明细和", block.get("declared_total_amount") == 700.0 and block.get("line_items_sum") == 700.0, json.dumps(block, ensure_ascii=False)[:200])
        check("口径块未把表内列合计混进总额", block.get("total_amount") != 400.0)

        r = client.get("/api/v1/summary", params={"date": "2026-09-03"})
        check("不传 biz_type 时两种口径并列返回", len(((r.json() or {}).get("data") or {}).get("blocks") or []) == 2, str(len(((r.json() or {}).get("data") or {}).get("blocks") or [])))

        title("14. 负责人汇报卡")
        r = client.post("/api/v1/reports/daily", json={"date": "2026-09-03", "include_unresolved": True})
        check("POST /reports/daily 返回 201", r.status_code == 201, f"{r.status_code} {r.text[:200]}")
        report = (r.json() or {}).get("data") or {}
        report_id = report.get("report_id") or ""
        check("拿到 report_id", bool(report_id), report_id)
        check("汇报含正文 markdown", bool(report.get("markdown")), str(report.get("markdown"))[:100])
        check("汇报含标题摘要", bool(report.get("headline")), str(report.get("headline"))[:100])
        check("汇报区分已确认金额与待确认金额", report.get("confirmed_amount") is not None and report.get("pending_amount") is not None, f"confirmed={report.get('confirmed_amount')} pending={report.get('pending_amount')}")
        check("汇报列出待人工确认数", (report.get("pending_review_count") or 0) >= 0, str(report.get("pending_review_count")))
        r = client.get(f"/api/v1/reports/daily/{report_id}")
        check("重取汇报返回 200", r.status_code == 200, str(r.status_code))
        check("不存在的汇报返回 404", client.get("/api/v1/reports/daily/nope").status_code == 404)

        title("15. 裁决日志导出（审计留痕）")
        r = client.get(f"/api/v1/requests/{adv_id}/decisions", params={"format": "csv"})
        check("CSV 导出返回 200", r.status_code == 200, str(r.status_code))
        check("CSV 含表头", "anomaly_id" in r.text, str(r.text.splitlines()[:1]))
        lines = [ln for ln in r.text.splitlines() if ln.strip()]
        check("CSV 含 4 条裁决", len(lines) == 5, str(len(lines)))
        check("CSV 记录了操作人", "e2e" in r.text)
        r = client.get(f"/api/v1/requests/{adv_id}/decisions")
        check("JSON 导出返回 200 且为数组", r.status_code == 200 and r.text.strip().startswith("["), r.text[:80])
        try:
            entries = json.loads(r.text)
            check("JSON 导出含 4 条", len(entries) == 4, str(len(entries)))
            check(
                "日志可追溯到具体异常与规则",
                all(e.get("anomaly_id") and e.get("rule_id") and e.get("severity") for e in entries),
            )
            check(
                "日志记录原始值与终值（审计可回溯）",
                any(e.get("final_value") for e in entries),
                json.dumps([[e.get("original_value"), e.get("final_value")] for e in entries], ensure_ascii=False)[:200],
            )
            check("日志不含枚举对象字面量（str(Enum) 污染）", "AnomalyCode." not in r.text and "Severity." not in r.text and "Decision." not in r.text, r.text[:120])
        except json.JSONDecodeError:
            check("JSON 导出可解析", False, r.text[:120])
        check("日志按 request 隔离（不会串到另一批次）", all(e.get("request_id") == adv_id for e in json.loads(r.text)))

        title("16. 错误路径（不存在资源应 404，不是 500）")
        check("不存在的 request 返回 404", client.get("/api/v1/requests/nope").status_code == 404)
        check("不存在的 table 返回 404", client.get("/api/v1/account-tables/nope").status_code == 404)
        check(
            "空文本解析应 4xx",
            400 <= client.post("/api/v1/requests/parse", json={"raw_text": "   "}).status_code < 500,
        )
        check(
            "无日期汇总应 4xx",
            400 <= client.get("/api/v1/summary").status_code < 500,
            str(client.get("/api/v1/summary").status_code),
        )

    print("\n" + "=" * 68)
    if _failures:
        print(f"结果：{_checks - len(_failures)}/{_checks} 通过，{len(_failures)} 项失败")
        for item in _failures:
            print(f"  - {item}")
        return 1
    print(f"结果：{_checks}/{_checks} 全部通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
